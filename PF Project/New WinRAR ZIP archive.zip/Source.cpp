//#include<SFML\Graphics.hpp>
//#include<iostream>
//using namespace std;
//using namespace sf;
//bool samefound(int arr[][8], int n) {
//
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == arr[i][j - 1] && arr[i][j] == arr[i][j + 1]) {
//				arr[i][j] = 0;
//				arr[i][j + 1] = 0;
//				arr[i][j - 1] = 0;
//				return true;
//			}
//			else if (arr[i][j] == arr[i + 1][j] && arr[i][j] == arr[i - 1][j]) {
//				arr[i][j] = 0;
//				arr[i - 1][j] = 0;
//				arr[i + 1][j] = 0;
//				return true;
//			}
//		}
//	}
//	return false;
//}
//
//void swap(int& a, int& b) {
//	int temp = a;
//	a = b;
//	b = temp;
//}
//
//void randomiseArray(int arr[][8], int n) {
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			arr[i][j] = rand() % 6 + 1;
//		}
//	}
//}
//
//void printArray(int arr[][8], int n) {
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//}
//int main() {
//	const int n = 8;
//	int arr[n][n];
//	randomiseArray(arr, n);
//	sf::RenderWindow newWindow;
//	newWindow.create(sf::VideoMode(1500, 1000), "New Window");
//
//	// Load background image
//	sf::Texture backgroundTexture;
//	backgroundTexture.loadFromFile("newback.jpg");
//	sf::Sprite backgroundSprite(backgroundTexture);
//
//	// Create a square with white background
//	sf::RectangleShape square(sf::Vector2f(560, 560));
//	square.setFillColor(sf::Color::Black);
//	square.setPosition(500, 200);
//	//shapes
//	Sprite shape;
//	Sprite shape1;
//	Texture shape1texture;
//	shape1texture.loadFromFile("shape1.png");
//	Sprite shape2;
//	Texture shape2texture;
//	shape2texture.loadFromFile("shape2.png");
//	Sprite shape3;
//	Texture shape3texture;
//	shape3texture.loadFromFile("shape3.png");
//	Sprite shape4;
//	Texture shape4texture;
//	shape4texture.loadFromFile("shape4.png");
//	Sprite shape5;
//	Texture shape5texture;
//	shape5texture.loadFromFile("shape5.png");
//	Sprite shape6;
//	Texture shape6texture;
//	shape6texture.loadFromFile("shape6.png");
//	while (newWindow.isOpen()) {
//		sf::Event event;
//		while (newWindow.pollEvent(event)) {
//			if (event.type == sf::Event::Closed) {
//				newWindow.close();
//			}
//			//assigning shapes
//			newWindow.clear();
//
//			// Draw the background
//			newWindow.draw(backgroundSprite);
//			for (int i = 0;i < n;i++) {
//				for (int j = 0;j < n;j++) {
//					if (arr[i][j] == 1) {
//						shape = shape1;
//						shape.setPosition((70 * i), (j * 70));
//						shape.setScale(0.25, 0.25);
//						// Adjust positions as needed 
//
//						newWindow.draw(shape);
//					}
//					else if (arr[i][j] == 2) {
//						shape = shape2;
//						shape.setPosition((70 * i), (70 * j));
//						shape.setScale(0.25, 0.25);
//						newWindow.draw(shape);
//					}
//					else if (arr[i][j] == 3) {
//						shape = shape3;
//						shape.setPosition((70 * i), (70 * j));
//						shape.setScale(0.25, 0.25);
//						newWindow.draw(shape);
//					}
//					else if (arr[i][j] == 4) {
//						shape = shape4;
//						shape.setPosition((70 * i), (70 * j));
//						shape.setScale(0.25, 0.25);
//						newWindow.draw(shape);
//					}
//					else if (arr[i][j] == 5) {
//						shape = shape5;
//						shape.setPosition((70 * i), (70 * j));
//						shape.setScale(0.25, 0.25);
//						newWindow.draw(shape);
//					}
//					else if (arr[i][j] == 6) {
//						shape = shape6;
//						shape.setPosition((70 * i), (70 * j));
//						shape.setScale(0.25, 0.25);
//						newWindow.draw(shape);
//					}
//				}
//			}
//		}
//	}
//	newWindow.display();
//
//}