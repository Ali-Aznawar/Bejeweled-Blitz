//#include <SFML/Graphics.hpp>
//#include <iostream>
//using namespace std;
//using namespace sf;
//
//bool samefound(int arr[][8], int n) {
//
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == arr[i][j - 1] && arr[i][j] == arr[i][j + 1]) {
//				arr[i][j] = 0;
//				arr[i][j + 1] = 0;
//				arr[i][j - 1] = 0;
//				return true;
//			}
//			else if (arr[i][j] == arr[i + 1][j] && arr[i][j] == arr[i - 1][j]) {
//				arr[i][j] = 0;
//				arr[i - 1][j] = 0;
//				arr[i + 1][j] = 0;
//				return true;
//			}
//		}
//	}
//	return false;
//}
//
//void swap(int& a, int& b) {
//	int temp = a;
//	a = b;
//	b = temp;
//}
//
//void randomiseArray(int arr[][8], int n) {
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			arr[i][j] = rand() % 6 + 1;
//		}
//	}
//}
//
//void printArray(int arr[][8], int n) {
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//}
//
//int main() {
//	const int n = 8;
//	int arr[n][n] = { 0 };
//
//	
//
//
//	randomiseArray(arr, n);
//	cout << "the matrix is:" << endl;
//	printArray(arr, n);
//
//	cout << "enter the address of the entery you want to swap:" << endl;
//	int i = 0, j = 0;
//	cin >> i >> j;
//	char action = '\0';
//	cout << "enter w if you want to swap with upper entry,s for lower,d for right,a for left " << endl;
//	cin >> action;
//
//	if (action == 'a') {
//
//		swap(arr[i][j], arr[i][j - 1]);
//
//		if (!samefound) {
//			swap(arr[i][j - 1], arr[i][j]);
//		}
//	}
//	else if (action == 's') {
//		swap(arr[i][j], arr[i + 1][j]);
//		if (!samefound) {
//			swap(arr[i + 1][j], arr[i][j]);
//		}
//	}
//	else if (action == 'w') {
//		swap(arr[i][j], arr[i - 1][j]);
//		if (!samefound) {
//			swap(arr[i - 1][j], arr[i][j]);
//		}
//	}
//	else if (action == 'd') {
//		swap(arr[i][j], arr[i][j + 1]);
//		if (!samefound) {
//			swap(arr[i][j + 1], arr[i][j]);
//		}
//	}
//	cout << "//////" << endl;
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
// ////////////////////////////////////////////
 //  int i = overlayBox.getPosition().x / 70;

 //           int j = overlayBox.getPosition().y / 70;



 //           if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && overlayBox.getPosition().y > 0 && j > 0) {
 //               overlayBox.move(0, -70);
 //	swap(arr[i][j], arr[i - 1][j]);
	//	if (!samefound) {
	//		swap(arr[i - 1][j], arr[i][j]);
	//	}
	//}
 //              
 //           }
 //           else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && overlayBox.getPosition().x < (70 * 7) && i < 7) {
 //               overlayBox.move(70, 0);
 //               swap(arr[i][j], arr[i][j + 1]);
	//	if (!samefound) {
	//		swap(arr[i][j + 1], arr[i][j]);
	//	}
	//}
 //           else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && overlayBox.getPosition().x > 0 && i > 0) {
 //               overlayBox.move(-70, 0);
 //               
	//	swap(arr[i][j], arr[i][j - 1]);

	//	if (!samefound) {
	//		swap(arr[i][j - 1], arr[i][j]);
	//	}
	//}
 //           else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && overlayBox.getPosition().y < (70 * 7) && j < 7) {
 //               overlayBox.move(0, 70);
 //              swap(arr[i][j], arr[i + 1][j]);
	//	if (!samefound) {
	//		swap(arr[i + 1][j], arr[i][j]);
	//	}
	//}
////
//
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == arr[i][j + 1] && arr[i][j] == arr[i][j + 2] && arr[i][j] == arr[i][j + 3]) {
//				arr[i][j] = 0;
//				arr[i][j + 1] = 0;
//				arr[i][j + 2] = 0;
//				arr[i][j + 3] = 0;
//
//			}
//			else if (arr[i][j] == arr[i + 1][j] && arr[i][j] == arr[i + 2][j] && arr[i][j] == arr[i + 3][j]) {
//				arr[i][j] = 0;
//				arr[i + 1][j] = 0;
//				arr[i + 2][j] = 0;
//				arr[i + 3][j] = 0;
//			}
//		}
//	}
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == arr[i][j - 1] && arr[i][j] == arr[i][j + 1]) {
//				arr[i][j] = 0;
//				arr[i][j + 1] = 0;
//				arr[i][j - 1] = 0;
//
//			}
//			else if (arr[i][j] == arr[i + 1][j] && arr[i][j] == arr[i - 1][j]) {
//				arr[i][j] = 0;
//				arr[i - 1][j] = 0;
//				arr[i + 1][j] = 0;
//
//			}
//		}
//	}
//
//	cout << "//////" << endl;
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//
//	cout << "//////" << endl;
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == 0 || arr[i][j] < 0) {
//				arr[i][j] = rand() % 6 + 1;
//
//			}
//		}
//
//	}
//	cout << "//////" << endl;
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//	cout << "///////////assigning shapes/////////////" << endl;
//	for (int i = 0;i < n;i++) {
//		for (int j = 0;j < n;j++) {
//			if (arr[i][j] == 1) {
//				cout << "a" << " ";
//			}
//			else if (arr[i][j] == 2) {
//				cout << "b" << " ";
//			}
//			else if (arr[i][j] == 3) {
//				cout << "c" << " ";
//			}
//			else if (arr[i][j] == 4) {
//				cout << "d" << " ";
//			}
//			else if (arr[i][j] == 5) {
//				cout << "e" << " ";
//			}
//			else if (arr[i][j] == 6) {
//				cout << "f" << " ";
//			}
//		}
//		cout << endl;
//	}
//	return 0;
//}